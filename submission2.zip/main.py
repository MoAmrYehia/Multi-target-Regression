import pandas as pd

test = pd.read_csv("../Track 1/test.csv")

# just sending simulated values as the answer
submission = test[["id", "x_sim", "y_sim", "z_sim", "Vx_sim", "Vy_sim", "Vz_sim"]]





X_test =submission #Test Values

import joblib
#Save model
filename = 'PositionRegressor.sav'
regressorP = joblib.load(filename)
Y_predP = regressorP.predict(X_test)

filename = 'VelocityRegressor.sav'
regressorV = joblib.load(filename)
Y_predV = regressorV.predict(X_test)

d = {'id': submission.iloc[:, 0], 'x': Y_predP[:, 0],'y':Y_predP[:,1],'z':Y_predP[:,2],'Vx':Y_predV[:,0],'Vy':Y_predV[:,1],'Vz':Y_predV[:,2]}
submission = pd.DataFrame.from_dict(d)
submission.to_csv("submission.csv", index=False)
